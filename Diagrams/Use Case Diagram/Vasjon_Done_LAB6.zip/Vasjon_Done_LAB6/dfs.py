def dfs_pathFinder(graph,start,goal):
    q = [[start]]
    v = []
    while q:
        path = q.pop(0)
        state = path[-1]
        i = 0
        if state == goal:
            print("The shortest path is:", path)
            break
        if state not in v:
            v.append(state)
        children = graph[state]
        for child in children:
            if child not in v:
                newPath = path + list(child)
                q.insert(i,newPath)
                i+=1
                v.append(child)


graph = {'A': ['B', 'H'],
         'H': ['A', 'B', 'G'],
         'B': ['A', 'C', 'H'],
         'C': ['B', 'D', 'G'],
         'G': ['D', 'C', 'F', 'H'],
         'D': ['C', 'E', 'F', 'G'],
         'E': ['D'],
         'F': ['D', 'G']
        }
dfs_pathFinder(graph, 'C', 'F')