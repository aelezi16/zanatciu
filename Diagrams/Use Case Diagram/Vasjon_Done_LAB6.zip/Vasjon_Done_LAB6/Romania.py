def bfs_pathFinder(graph,start,goal):
    q = [[start]]
    v = []
    while q:
        path = q.pop(0)
        state = path[-1]
        if state == goal:
            print("The shortest path using BFS is:", path)
            break
        children = graph[state]
        for child in range(len(children)):
            if children[child] not in v:
                newPath = path.copy()
                newPath.append(children[child])
                q.append(newPath)
                v.append(children[child])


def dfs_pathFinder(graph,start,goal):
    q = [[start]]
    v = []
    while q:
        path = q.pop(0)
        state = path[-1]
        i = 0
        if state == goal:
            print("The shortest path using DFS is:", path)
            break
        if state not in v:
            v.append(state)
        children = graph[state]
        for child in range(len(children)):
            if children[child] not in v:
                newPath = path.copy()
                newPath.append(children[child])
                q.insert(child,newPath)
                v.append(children[child])

start = str(input("Starting from: "))
goal = str(input("Final goal is: "))
graph = {
    'Oradea' : ['Zerind','Sibiu'],
    'Zerind' : ['Oradea','Arad'],
    'Arad' : ['Zerind','Timisoara','Sibiu'],
    'Sibiu' : ['Rimnicu Vilcea','Fagaras','Arad','Oradea'],
    'Fagaras' :['Sibiu','Bucharest'],
    'Bucharest' : ['Urziceni','Giurgiu','Pitesti'],
    'Vaslui' : ['Iasi','Urziceni'],
    'Iasi' : ['Neamt', 'Vaslui'],
    'Neamt' : ['Iasi'],
    'Pitesti' : ['Rimnicu Vilcea','Bucharest','Craiova'],
    'Giurgiu' :['Bucharest'],
    'Timisoara' : ['Lugoj','Arad'],
    'Lugoj': ['Mehadia','Timisoara'],
    'Mehadia' : ['Lugoj','Drobeta'],
    'Drobeta' : ['Mehadia','Craiova'],
    'Craiova' : ['Drobeta','Pitesti','Rimnicu Vilcea'],
    'Rimnicu Vilcea' : ['Sibiu','Pitesti','Craiova'],
    'Urziceni' : ['Bucharest','Hirsova','Vaslui'],
    'Hirsova' : ['Eforie','Urziceni'],
    'Eforie' : ['Hirsova']
    }


bfs_pathFinder(graph, start , goal)
dfs_pathFinder(graph, start, goal)